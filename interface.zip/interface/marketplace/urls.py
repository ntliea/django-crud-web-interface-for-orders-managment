from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name=""),

    path("register", views.register, name="register"),

    path("login", views.login, name="login"),

    path("logout", views.logout, name="logout"),

    path("dashboard", views.dashboard, name="dashboard"),

    path("view_streets", views.view_streets, name="view_streets"),

    path("add_street", views.add_street, name="add_street"),

    path("street/<int:street_id>", views.street, name="street"),

    path("update_street/<int:street_id>", views.update_street, name="update_street"),

    path("delete_street/<int:street_id>", views.delete_street, name="delete_street"),

    path("view_cities", views.view_cities, name="view_cities"),

    path("add_city", views.add_city, name="add_city"),

    path("city/<int:city_id>", views.city, name="city"),

    path("update_city/<int:city_id>", views.update_city, name="update_city"),

    path("delete_city/<int:city_id>", views.delete_city, name="delete_city"),

    path("view_users", views.view_users, name="view_users"),

    path("add_user", views.add_user, name="add_user"),

    path("user/<int:user_id>", views.user, name="user"),

    path("update_user/<int:user_id>", views.update_user, name="update_user"),

    path("delete_user/<int:user_id>", views.delete_user, name="delete_user"),

    path("view_adresses", views.view_adresses, name="view_adresses"),

    path("add_adress", views.add_adress, name="add_adress"),

    path("adress/<int:adress_id>", views.adress, name="adress"),

    path("update_adress/<int:adress_id>", views.update_adress, name="update_adress"),

    path("delete_adress/<int:adress_id>", views.delete_adress, name="delete_adress"),

    path("view_orders", views.view_orders, name="view_orders"),

    path("sort_orders/<int:city_id>", views.sort_orders, name="sort_orders"),

    path("add_order", views.add_order, name="add_order"),

    path("order/<int:order_id>", views.order, name="order"),

    path("update_order/<int:order_id>", views.update_order, name="update_order"),

    path("delete_order/<int:order_id>", views.delete_order, name="delete_order"),

    path("view_statuses", views.view_statuses, name="view_statuses"),

    path("add_status", views.add_status, name="add_status"),

    path("status/<int:status_id>", views.status, name="status"),

    path("update_status/<int:status_id>", views.update_status, name="update_status"),

    path("delete_status/<int:status_id>", views.delete_status, name="delete_status"),

    path("view_orders_statuses", views.view_orders_statuses, name="view_orders_statuses"),

    path("add_order_status", views.add_order_status, name="add_order_status"),

    path("order_status/<int:order_status_id>", views.order_status, name="order_status"),

    path("update_order_status/<int:order_status_id>", views.update_order_status, name="update_order_status"),

    path("delete_order_status/<int:order_status_id>", views.delete_order_status, name="delete_order_status"),

]