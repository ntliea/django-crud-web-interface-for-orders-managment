from django.shortcuts import render, redirect
from .forms import CreateUserForm, LoginForm
from django.contrib.auth.models import auth
from django.contrib.auth import authenticate
from django.contrib.auth.decorators import login_required
from django.db import connection


def index(request):

    return render(request, 'marketplace/index.html')


# регистрация
def register(request):

    form = CreateUserForm()

    if request.method == "POST":
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("login")

    context = {'form': form}
    return render(request, 'marketplace/register.html', context=context)


# вход
def login(request):

    form = LoginForm()

    if request.method == "POST":
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                auth.login(request, user)
                return redirect("dashboard")

    context = {'form': form}

    return render(request, 'marketplace/login.html', context=context)


# выход
def logout(request):

    auth.logout(request)

    return redirect("login")


# страница-обзор с ограничением доступа (только для авторизованных)
@login_required(login_url='login')
def dashboard(request):

    return render(request, 'marketplace/dashboard.html')


''' Создадим функцию для преобразования списка кортежей от fetchall() в список словарей,
 где ключ - название колонки таблицы, а значение - сами данные '''

def dictfetchall(cursor):

    desc = cursor.description

    '''cursor.description возвращает названия столбцов из запроса
    Предоставляет имена столбцов последнего запроса. Чтобы оставаться совместимым с API-интерфейсом Python DB,
    он возвращает кортеж из 7 элементов для каждого столбца,
    где последние шесть элементов каждого кортежа равны None.'''

    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()  # fetchall возвращает кортеж из всех строк, полученных при запросе
    ]


# Работа с таблицой streets (улицы)
# CRUD-интерфейс (создание, чтение, обновление, удаление записей)

@login_required(login_url='login')
def view_streets(request):
    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.streets ORDER BY id DESC')
    streets_list = dictfetchall(c)
    context = {
        'streets_list': streets_list
    }
    return render(request, 'marketplace/view_streets.html', context)


@login_required(login_url='login')
def add_street(request):
    if request.method == "POST":
        data = request.POST.get('street_name')
        c = connection.cursor()
        try:
            c.execute(f'''INSERT INTO  marketplace.streets (name) values ('{data}')''')
        finally:
            c.close()
        return redirect("view_streets")
    return render(request, 'marketplace/add_street.html')


@login_required(login_url='login')
def street(request, street_id):
    c = connection.cursor()
    c.execute(f"SELECT name FROM marketplace.streets WHERE id = {street_id}")
    street_name = c.fetchone()[0]
    context = {'street_name': street_name, 'street_id': street_id}
    return render(request, 'marketplace/street_card.html', context)


@login_required(login_url='login')
def update_street(request, street_id):
    if request.method == "POST":
        data = request.POST.get('street_name')
        c = connection.cursor()
        try:
            c.execute(f'''UPDATE marketplace.streets SET name = '{data}' WHERE id = {street_id} ''')
        finally:
            c.close()
        return redirect("view_streets")

    c = connection.cursor()
    c.execute(f"SELECT name FROM marketplace.streets WHERE id = {street_id}")
    street_name = c.fetchone()[0]
    context = {'street_name': street_name, 'street_id': street_id}
    return render(request, 'marketplace/update_street.html', context)


@login_required(login_url='login')
def delete_street(request, street_id):
    c = connection.cursor()
    try:
        c.execute(f'''DELETE from marketplace.streets WHERE id = {street_id} ''')
    finally:
        c.close()
    return redirect("view_streets")


# Работа с таблицой cities (города)
# CRUD-интерфейс (создание, чтение, обновление, удаление записей)

@login_required(login_url='login')
def view_cities(request):
    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.cities ORDER BY id DESC')
    cities_list = dictfetchall(c)
    context = {
        'cities_list': cities_list
    }
    return render(request, 'marketplace/view_cities.html', context)


@login_required(login_url='login')
def add_city(request):
    if request.method == "POST":
        data = request.POST.get('city_name')
        c = connection.cursor()
        try:
            c.execute(f'''INSERT INTO  marketplace.cities (name) values ('{data}')''')
        finally:
            c.close()
        return redirect("view_cities")
    return render(request, 'marketplace/add_city.html')


@login_required(login_url='login')
def city(request, city_id):
    c = connection.cursor()
    c.execute(f"SELECT name FROM marketplace.cities WHERE id = {city_id}")
    city_name = c.fetchone()[0]
    context = {'city_name': city_name, 'city_id': city_id}
    return render(request, 'marketplace/city_card.html', context)


@login_required(login_url='login')
def update_city(request, city_id):
    if request.method == "POST":
        data = request.POST.get('city_name')
        c = connection.cursor()
        try:
            c.execute(f'''UPDATE marketplace.cities SET name = '{data}' WHERE id = {city_id} ''')
        finally:
            c.close()
        return redirect("view_cities")

    c = connection.cursor()
    c.execute(f"SELECT name FROM marketplace.cities WHERE id = {city_id}")
    city_name = c.fetchone()[0]
    context = {'city_name': city_name, 'city_id': city_id}
    return render(request, 'marketplace/update_city.html', context)


@login_required(login_url='login')
def delete_city(request, city_id):
    c = connection.cursor()
    try:
        c.execute(f'''DELETE from marketplace.cities WHERE id = {city_id} ''')
    finally:
        c.close()
    return redirect("view_cities")


@login_required(login_url='login')
def view_users(request):
    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.users ORDER BY id DESC')
    users_list = dictfetchall(c)
    context = {
        'users_list': users_list
    }
    return render(request, 'marketplace/view_users.html', context)


@login_required(login_url='login')
def add_user(request):
    if request.method == "POST":
        user_name = request.POST.get('user_name')
        user_email = request.POST.get('user_email')
        user_phone = request.POST.get('user_phone')
        user_password = request.POST.get('user_password')
        c = connection.cursor()
        try:
            c.execute(f'''INSERT INTO  marketplace.users (name, email_adress, phone_number, user_password, has_admin_rights) values ('{user_name}', '{user_email}', '{user_phone}', '{user_password}', 0)''')
        finally:
            c.close()
        return redirect("view_users")
    return render(request, 'marketplace/add_user.html')


# Работа с таблицой users (пользователи)
# CRUD-интерфейс (создание, чтение, обновление, удаление записей)

@login_required(login_url='login')
def user(request, user_id):
    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.users WHERE id = {user_id}")
    result = c.fetchone()
    user_name = result[1]
    user_email = result[2]
    user_phone = result[4]
    context = {
        'user_id': user_id,
        'user_name': user_name,
        'user_email': user_email,
        'user_phone': user_phone,
    }
    return render(request, 'marketplace/user_card.html', context)


@login_required(login_url='login')
def update_user(request, user_id):
    if request.method == "POST":
        user_name = request.POST.get('user_name')
        user_email = request.POST.get('user_email')
        user_phone = request.POST.get('user_phone')
        c = connection.cursor()
        try:
            c.execute(f'''UPDATE marketplace.users SET name = '{user_name}', 
             email_adress = '{user_email}', phone_number = '{user_phone}', user_password = 'password', 
             has_admin_rights = '0' WHERE id = {user_id} ''')
        finally:
            c.close()
        return redirect("view_users")

    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.users WHERE id = {user_id}")
    result = c.fetchone()
    user_name = result[1]
    user_email = result[2]
    user_phone = result[4]
    context = {
        'user_id': user_id,
        'user_name': user_name,
        'user_email': user_email,
        'user_phone': user_phone
    }
    return render(request, 'marketplace/update_user.html', context)


@login_required(login_url='login')
def delete_user(request, user_id):
    c = connection.cursor()
    try:
        c.execute(f'''DELETE from marketplace.users WHERE id = {user_id} ''')
    finally:
        c.close()
    return redirect("view_users")


# Работа с таблицой adresses (адреса доставок)
# CRUD-интерфейс (создание, чтение, обновление, удаление записей)

@login_required(login_url='login')
def view_adresses(request):
    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.delivery_adresses ORDER BY id DESC')
    adresses_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.cities')
    cities_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.streets')
    streets_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.users')
    users_list = dictfetchall(c)

    context = {
        'adresses_list': adresses_list,
        'cities_list': cities_list,
        'streets_list': streets_list,
        'users_list': users_list
    }
    return render(request, 'marketplace/view_adresses.html', context)


@login_required(login_url='login')
def add_adress(request):
    if request.method == "POST":
        adress_city_id = request.POST.get('adress_city_id')
        adress_street_id = request.POST.get('adress_street_id')
        adress_user_id = request.POST.get('adress_user_id')
        c = connection.cursor()
        try:
            c.execute(f'''INSERT INTO  marketplace.delivery_adresses (city_id, street_id, user_id) 
                        values ('{adress_city_id}', '{adress_street_id}', '{adress_user_id}')''')
        finally:
            c.close()
        return redirect("view_adresses")

    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.cities')
    cities_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.streets')
    streets_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.users')
    users_list = dictfetchall(c)

    context = {
        'cities_list': cities_list,
        'streets_list': streets_list,
        'users_list': users_list,
    }

    return render(request, 'marketplace/add_adress.html', context)


@login_required(login_url='login')
def adress(request, adress_id):
    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.delivery_adresses WHERE id = {adress_id}")
    result = c.fetchone()
    adress_id = result[0]
    adress_city_id = result[1]
    adress_street_id = result[2]
    adress_user_id = result[3]

    c.execute(f"SELECT * FROM marketplace.cities WHERE id = {adress_city_id}")
    result = c.fetchone()
    adress_city_name = result[1]

    c.execute(f"SELECT * FROM marketplace.streets WHERE id = {adress_street_id}")
    result = c.fetchone()
    adress_street_name = result[1]

    c.execute(f"SELECT * FROM marketplace.users WHERE id = {adress_user_id}")
    result = c.fetchone()
    adress_user_name = result[1]

    context = {
        'adress_id': adress_id,
        'adress_city_id': adress_city_id,
        'adress_city_name': adress_city_name,
        'adress_street_id': adress_street_id,
        'adress_street_name': adress_street_name,
        'adress_user_id': adress_user_id,
        'adress_user_name': adress_user_name
    }
    return render(request, 'marketplace/adress_card.html', context)


@login_required(login_url='login')
def update_adress(request, adress_id):
    if request.method == "POST":
        adress_city_id = request.POST.get('adress_city_id')
        adress_street_id = request.POST.get('adress_street_id')
        adress_user_id = request.POST.get('adress_user_id')

        c = connection.cursor()
        try:
            c.execute(f'''UPDATE marketplace.delivery_adresses SET city_id = '{adress_city_id}', 
            street_id = '{adress_street_id}', user_id = '{adress_user_id}' WHERE id = {adress_id} ''')
        finally:
            c.close()
        return redirect("view_adresses")

    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.delivery_adresses WHERE id = {adress_id}")
    result = c.fetchone()
    adress_id = result[0]
    adress_city_id = result[1]
    adress_street_id = result[2]
    adress_user_id = result[3]

    c.execute('SELECT * FROM marketplace.cities')
    cities_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.streets')
    streets_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.users')
    users_list = dictfetchall(c)

    context = {
        'adress_id': adress_id,
        'adress_city_id': adress_city_id,
        'adress_street_id': adress_street_id,
        'adress_user_id': adress_user_id,

        'cities_list': cities_list,
        'streets_list': streets_list,
        'users_list': users_list,
    }
    return render(request, 'marketplace/update_adress.html', context)


@login_required(login_url='login')
def delete_adress(request, adress_id):
    c = connection.cursor()
    try:
        c.execute(f'''DELETE from marketplace.delivery_adresses WHERE id = {adress_id} ''')
    finally:
        c.close()
    return redirect("view_adresses")


# Работа с таблицой orders (заказы)
# CRUD-интерфейс (создание, чтение, обновление, удаление записей)
# Многотабличный запрос

@login_required(login_url='login')
def view_orders(request):
    c = connection.cursor()
    c.execute(
        ' SELECT marketplace.orders.* ,'
        ' marketplace.cities.name AS city_name,'
        ' marketplace.streets.name AS street_name,'
        ' marketplace.users.name AS user_name '

        ' FROM ((((marketplace.delivery_adresses INNER JOIN marketplace.cities '
        ' ON marketplace.delivery_adresses.city_id = marketplace.cities.id) '
        ' INNER JOIN marketplace.streets ON marketplace.delivery_adresses.street_id = marketplace.streets.id) '
        ' INNER JOIN marketplace.users ON marketplace.delivery_adresses.user_id = marketplace.users.id) '
        ' INNER JOIN marketplace.orders ON marketplace.orders.adress_id = marketplace.delivery_adresses.id) '
        ' ORDER BY date DESC '
    )
    orders_list = dictfetchall(c)

    c.execute('SELECT * from marketplace.cities')
    cities_list = dictfetchall(c)

    context = {
        'orders_list': orders_list,
        'cities_list': cities_list,
    }
    return render(request, 'marketplace/view_orders.html', context)


# Многотабличный запрос (JOIN) с условием для сортировки заказов по городу

@login_required(login_url='login')
def sort_orders(request, city_id):
    c = connection.cursor()
    c.execute(
        f''' SELECT marketplace.orders.* ,
         marketplace.cities.id AS city_id, 
         marketplace.cities.name AS city_name,
         marketplace.streets.name AS street_name,
         marketplace.users.name AS user_name 

         FROM ((((marketplace.delivery_adresses INNER JOIN marketplace.cities 
         ON marketplace.delivery_adresses.city_id = marketplace.cities.id) 
         INNER JOIN marketplace.streets ON marketplace.delivery_adresses.street_id = marketplace.streets.id) 
         INNER JOIN marketplace.users ON marketplace.delivery_adresses.user_id = marketplace.users.id) 
         INNER JOIN marketplace.orders ON marketplace.orders.adress_id = marketplace.delivery_adresses.id) 

         WHERE city_id = {city_id} ORDER BY date DESC '''
    )
    orders_list = dictfetchall(c)

    c.execute('SELECT * from marketplace.cities')
    cities_list = dictfetchall(c)

    context = {
        'orders_list': orders_list,
        'cities_list': cities_list,
    }
    return render(request, 'marketplace/view_orders_sort.html', context)


@login_required(login_url='login')
def add_order(request):
    if request.method == "POST":
        order_date = request.POST.get('order_date')
        order_summ = request.POST.get('order_summ')
        order_pay_method = request.POST.get('order_pay_method')
        order_receiving_method = request.POST.get('order_receiving_method')
        order_adress_id = request.POST.get('order_adress_id')
        c = connection.cursor()
        try:
            c.execute(f'''INSERT INTO  marketplace.orders (date, total_price, pay_method, receiving_method, adress_id) 
                        values ('{order_date}', '{order_summ}', '{order_pay_method}', 
                        '{order_receiving_method}', '{order_adress_id}')''')
        finally:
            c.close()
        return redirect("view_orders")

    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.delivery_adresses')
    adresses_list = dictfetchall(c)

    context = {
        'adresses_list': adresses_list,
    }

    return render(request, 'marketplace/add_order.html', context)


@login_required(login_url='login')
def order(request, order_id):
    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.orders WHERE id = {order_id}")
    result = c.fetchone()
    order_id = result[0]
    order_date = result[1]
    order_summ = result[2]
    order_pay_method = result[3]
    order_receiving_method = result[4]
    order_adress_id = result[5]

    context = {
        'order_id': order_id,
        'order_date': order_date,
        'order_summ': order_summ,
        'order_pay_method': order_pay_method,
        'order_receiving_method': order_receiving_method,
        'order_adress_id': order_adress_id
    }

    return render(request, 'marketplace/order_card.html', context)


@login_required(login_url='login')
def update_order(request, order_id):
    if request.method == "POST":
        order_date = request.POST.get('order_date')
        order_summ = request.POST.get('order_summ')
        order_pay_method = request.POST.get('order_pay_method')
        order_receiving_method = request.POST.get('order_receiving_method')
        order_adress_id = request.POST.get('order_adress_id')

        c = connection.cursor()
        try:
            c.execute(f'''UPDATE marketplace.orders SET date = '{order_date}', 
            total_price = '{order_summ}', pay_method = '{order_pay_method}',
            receiving_method = '{order_receiving_method}', adress_id = '{order_adress_id}' WHERE id = '{order_id}' ''')
        finally:
            c.close()
        return redirect("view_orders")

    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.orders WHERE id = {order_id}")
    result = c.fetchone()
    order_id = result[0]
    order_date = result[1]
    order_summ = result[2]
    order_pay_method = result[3]
    order_receiving_method = result[4]
    order_adress_id = result[5]

    c.execute('SELECT * FROM marketplace.delivery_adresses')
    adresses_list = dictfetchall(c)

    context = {
        'order_id': order_id,
        'order_date': order_date,
        'order_summ': order_summ,
        'order_pay_method': order_pay_method,
        'order_receiving_method': order_receiving_method,
        'order_adress_id': order_adress_id,
        'adresses_list': adresses_list,
    }
    return render(request, 'marketplace/update_order.html', context)


@login_required(login_url='login')
def delete_order(request, order_id):
    c = connection.cursor()
    try:
        c.execute(f'''DELETE from marketplace.orders WHERE id = {order_id} ''')
    finally:
        c.close()
    return redirect("view_orders")


# Работа с таблицой statuses (статусы заказов)
# CRUD-интерфейс (создание, чтение, обновление, удаление записей)

@login_required(login_url='login')
def view_statuses(request):
    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.statuses ORDER BY id DESC')
    statuses_list = dictfetchall(c)
    context = {
        'statuses_list': statuses_list
    }
    return render(request, 'marketplace/view_statuses.html', context)


@login_required(login_url='login')
def add_status(request):
    if request.method == "POST":
        data = request.POST.get('status_name')
        c = connection.cursor()
        try:
            c.execute(f'''INSERT INTO  marketplace.statuses (name) values ('{data}')''')
        finally:
            c.close()
        return redirect("view_statuses")
    return render(request, 'marketplace/add_status.html')


@login_required(login_url='login')
def status(request, status_id):
    c = connection.cursor()
    c.execute(f"SELECT name FROM marketplace.statuses WHERE id = {status_id}")
    status_name = c.fetchone()[0]
    context = {'status_name': status_name, 'status_id': status_id}
    return render(request, 'marketplace/status_card.html', context)


@login_required(login_url='login')
def update_status(request, status_id):
    if request.method == "POST":
        data = request.POST.get('status_name')
        c = connection.cursor()
        try:
            c.execute(f'''UPDATE marketplace.statuses SET name = '{data}' WHERE id = {status_id} ''')
        finally:
            c.close()
        return redirect("view_statuses")

    c = connection.cursor()
    c.execute(f"SELECT name FROM marketplace.statuses WHERE id = {status_id}")
    status_name = c.fetchone()[0]
    context = {'status_name': status_name, 'status_id': status_id}
    return render(request, 'marketplace/update_status.html', context)


@login_required(login_url='login')
def delete_status(request, status_id):
    c = connection.cursor()
    try:
        c.execute(f'''DELETE from marketplace.statuses WHERE id = {status_id} ''')
    finally:
        c.close()
    return redirect("view_statuses")


# Работа с таблицой orders_statuses (статусы заказов, промежуточная)
# CRUD-интерфейс (создание, чтение, обновление, удаление записей)

@login_required(login_url='login')
def view_orders_statuses(request):
    c = connection.cursor()
    c.execute('SELECT * FROM marketplace.orders_statuses ORDER BY id DESC')
    orders_statuses_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.statuses')
    statuses_list = dictfetchall(c)

    context = {
        'orders_statuses_list': orders_statuses_list,
        'statuses_list': statuses_list,
    }

    return render(request, 'marketplace/view_orders_statuses.html', context)


@login_required(login_url='login')
def add_order_status(request):
    if request.method == "POST":
        order_id = request.POST.get('order_id')
        status_id = request.POST.get('status_id')
        order_status_date = request.POST.get('order_status_date')
        c = connection.cursor()
        try:
            c.execute(f'''INSERT INTO  marketplace.orders_statuses (order_id, status_id, date) 
                        values ('{order_id}', '{status_id}', '{order_status_date}')''')
        finally:
            c.close()
        return redirect("view_orders_statuses")

    c = connection.cursor()

    c.execute('SELECT * FROM marketplace.orders')
    orders_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.statuses')
    statuses_list = dictfetchall(c)

    context = {
        'orders_list': orders_list,
        'statuses_list': statuses_list
    }

    return render(request, 'marketplace/add_order_status.html', context)


@login_required(login_url='login')
def order_status(request, order_status_id):
    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.orders_statuses WHERE id = {order_status_id}")
    result = c.fetchone()
    order_id = result[1]
    status_id = result[2]
    date = result[3]

    c.execute(f"SELECT * FROM marketplace.statuses WHERE id = {status_id}")
    result = c.fetchone()
    status_name = result[1]

    context = {
        'order_status_id': order_status_id,
        'order_id': order_id,
        'status_id': status_id,
        'date': date,
        'status_name': status_name,
    }

    return render(request, 'marketplace/order_status_card.html', context)


@login_required(login_url='login')
def update_order_status(request, order_status_id):
    if request.method == "POST":
        order_id = request.POST.get('order_id')
        status_id = request.POST.get('status_id')
        date = request.POST.get('date')

        c = connection.cursor()
        try:
            c.execute(f'''UPDATE marketplace.orders_statuses SET order_id = '{order_id}', 
            status_id = '{status_id}', date = '{date}' WHERE id = {order_status_id} ''')
        finally:
            c.close()
        return redirect("view_orders_statuses")

    c = connection.cursor()
    c.execute(f"SELECT * FROM marketplace.orders_statuses WHERE id = {order_status_id}")
    result = c.fetchone()
    order_id = result[1]
    status_id = result[2]
    date = result[3]

    c.execute('SELECT * FROM marketplace.orders')
    orders_list = dictfetchall(c)

    c.execute('SELECT * FROM marketplace.statuses')
    statuses_list = dictfetchall(c)

    context = {
        'order_status_id': order_status_id,
        'order_id': order_id,
        'status_id': status_id,
        'date': date,
        'orders_list': orders_list,
        'statuses_list': statuses_list
    }
    return render(request, 'marketplace/update_order_status.html', context)


@login_required(login_url='login')
def delete_order_status(request, order_status_id):
    c = connection.cursor()
    try:
        c.execute(f'''DELETE from marketplace.orders_statuses WHERE id = {order_status_id} ''')
    finally:
        c.close()
    return redirect("view_orders_statuses")


# многотабличный запрос с условием для сортировка заказов по сумме, по дате



